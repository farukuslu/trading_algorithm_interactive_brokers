# Remember -- a strategy takes in data and outputs trades.
from datetime import datetime

